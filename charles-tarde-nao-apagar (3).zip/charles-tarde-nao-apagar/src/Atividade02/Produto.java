package Atividade02;

public class Produto {
	private int codigo;
	private String nome;
	private double preco;
	private int quantidade;

//Método construtor	
	public Produto(int codigo) {
		this.codigo = codigo;
		System.out.println("Criando objeto com CODIGO...");
		}
	
	public Produto(int codigo, String nome) {
		this.codigo = codigo;
		this.nome = nome;
		System.out.println("Criando objeto com CODIGO e NOME...");
	}
	
	public Produto(int codigo, String nome, double preco, int quantidade) {
		this.codigo = codigo;
		this.nome = nome;
		this.preco = preco;
		this.quantidade = quantidade;
		System.out.println("Criando objeto com CODIGO, NOME, PREÇO e QUANTIDADE...");
	}

//Métodos Getters e Setters	
	public int getCodigo() {
		return this.codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getNome() {
		return this.nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public double getPreco() {
		return this.preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}
	public int getQuantidade() {
		return this.quantidade;
	}
	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}
		
}
