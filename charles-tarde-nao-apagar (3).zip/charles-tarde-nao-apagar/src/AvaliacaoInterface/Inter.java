package AvaliacaoInterface;

public interface Inter {

	public abstract double getPLR();
	
	
}
