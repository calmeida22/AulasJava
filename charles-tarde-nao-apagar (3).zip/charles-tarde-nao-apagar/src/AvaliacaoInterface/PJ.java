package AvaliacaoInterface;

public class PJ extends Funcionario implements Inter{

	private CalcPLR func;
	private double	porcentagem;
	
	PJ(double salario){
		this.func = new CalcPLR();
		this.func.setSalario(salario);
		this.porcentagem = 1;
	}
	
	@Override
	public double getPLR() {
		return this.func.getPLR(porcentagem);
	}

	public String getNome() {
		return this.func.getNome();
	}
	public void setNome(String nome) {
		this.func.setNome(nome);
	}
	public int getMatricula() {
		return this.func.getMatricula();
	}
	public void setMatricula(int matricula) {
		this.func.setMatricula(matricula);
	}
	public double getSalario() {
		return this.func.getSalario();
	}
	public void setSalario(double salario) {
		this.func.setSalario(salario);
	}	
	
}
