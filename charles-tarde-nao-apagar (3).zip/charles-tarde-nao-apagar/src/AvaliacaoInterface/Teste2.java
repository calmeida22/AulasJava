package AvaliacaoInterface;

public class Teste2 {
	
	public static void main(String[] args) {
	ExFunc1 ee1 = new ExFunc1(1000);
	System.out.println("Sal Exfunc1: "+ee1.getSalario());
	System.out.println("PLR Exfunc1: "+ee1.getPLR());
	
	System.out.println();
	
	Exfunc2 ee2 = new Exfunc2(1000);
	System.out.println("Sal Exfunc2: "+ee2.getSalario());
	System.out.println("PLR Exfunc2: "+ee2.getPLR());
	
	System.out.println();
	
	CLT c1 = new CLT(1000);
	System.out.println("Sal CLT1: "+c1.getSalario());
	System.out.println("PLR CLT2: "+c1.getPLR());
	
	System.out.println();
	
	PJ p1 = new PJ(1000);
	System.out.println("Sal PJ2: "+p1.getSalario());
	System.out.println("PLR PJ2: "+p1.getPLR());
}
}