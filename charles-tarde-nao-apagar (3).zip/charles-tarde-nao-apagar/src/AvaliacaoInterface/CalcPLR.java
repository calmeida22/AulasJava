package AvaliacaoInterface;

public class CalcPLR {

	private String nome;
	private int matricula;
	private double salario;
		
	public double getPLR(double porcentagem) {
		return this.salario*porcentagem;
	}

	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getMatricula() {
		return this.matricula;
	}

	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}

	public double getSalario() {
		return this.salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}
}
