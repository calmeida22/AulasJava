package AvaliacaoInterface;

public class ExFunc1 implements Inter{

	private CalcPLR exfunc;
	private double	porcentagem;
	
	ExFunc1(double salario){
		this.exfunc = new CalcPLR();
		this.exfunc.setSalario(salario);
		this.porcentagem = 0.5;
	}
	
	@Override
	public double getPLR() {
		return this.exfunc.getPLR(porcentagem);
	}
	public String getNome() {
		return this.exfunc.getNome();
	}
	public void setNome(String nome) {
		this.exfunc.setNome(nome);
	}
	public int getMatricula() {
		return this.exfunc.getMatricula();
	}
	public void setMatricula(int matricula) {
		this.exfunc.setMatricula(matricula);
	}
	public double getSalario() {
		return this.exfunc.getSalario();
	}
	public void setSalario(double salario) {
		this.exfunc.setSalario(salario);
	}
	

}
