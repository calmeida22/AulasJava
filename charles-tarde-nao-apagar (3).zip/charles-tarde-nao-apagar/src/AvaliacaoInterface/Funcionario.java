package AvaliacaoInterface;

public abstract class Funcionario {

	public abstract double getPLR();
	
}
