package AvaliaçãoHeranca;

public class TesteInterface {

	public static void main(String[] args) {
		ExFuncionario e1 = new ExFuncionario(1000);
		
		System.out.println("Salário ExFuncionário: "+e1.getSalario()+"\nPLR ExFuncionario: "+e1.getPLR());		

	}

}
