package AvaliaçãoHeranca;

public class PJ extends Funcionario{

	PJ(double salario){
		super.setSalario(salario);
	}
	
	@Override
	public double getPLR() {
		System.out.println("Calculo PLR PJ...");
		return this.getSalario()*1;
	}

}
