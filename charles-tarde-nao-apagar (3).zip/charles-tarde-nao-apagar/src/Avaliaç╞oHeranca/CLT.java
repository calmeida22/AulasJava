package AvaliaçãoHeranca;

public class CLT extends Funcionario {

	CLT(double salario) {
		super.setSalario(salario);
	}

	@Override
	public double getPLR() {
		System.out.println("Calculo PLR CLT...");
		return this.getSalario()*0.9;
		
	}

}
