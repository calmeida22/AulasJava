package AvaliaçãoHeranca;

public class TesteHeranca {

	public static void main(String[] args) {
		CLT c1 = new CLT(1000);
		PJ p1 = new PJ(1000);
		
		System.out.println();
		
		System.out.println("Salário CLT: "+c1.getSalario()+"\nPLR CLT: "+c1.getPLR()+"\nSalário PJ: "+p1.getSalario()+"\nPLR PJ: "+p1.getPLR());
		
		Filha f1 = new Filha(1000);
		
		System.out.println();		
		
		System.out.println("Salário: "+f1.getSalario()+"\nPLR Filha: "+f1.getPLR());
	
		

	}

}
