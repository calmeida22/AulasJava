package AvaliaçãoHeranca;

public interface InterPLR {

	public double getPLR();
	
}
