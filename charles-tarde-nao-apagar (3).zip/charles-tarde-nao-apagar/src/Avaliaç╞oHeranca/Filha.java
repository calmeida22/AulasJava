package AvaliaçãoHeranca;

public class Filha extends Funcionario {

	Filha(double salario){
		super.setSalario(salario);
	}
	
	@Override
	public double getPLR() {
		System.out.println("Calculando PLR Filha...");
		return this.getSalario()*0.5;
	}

}
