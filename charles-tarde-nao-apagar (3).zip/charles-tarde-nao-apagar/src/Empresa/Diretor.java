package Empresa;

public class Diretor extends Funcionario implements Autenticavel{
	
	private AutenticacaoUtil autenticou;
	
	public Diretor() {
		this.autenticou = new AutenticacaoUtil();
	}
	
	@Override
	public double getBonificacao() {
		return super.getSalario()+1000;//super para indicar que salário é atributo da classe mãe (boa prática)
	}
	@Override
	public void setSenha(int senha) {
		this.autenticou.setSenha(senha);
		
	}

	@Override
	public boolean autentica(int senha) {
		if (this.autenticou.autentica(senha)) {
			return this.autenticou.autentica(senha);
		} else {
			return false;
		}
	}
}
