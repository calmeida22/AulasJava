public interface Tributavel {

public abstract double getValorImposto();

}
