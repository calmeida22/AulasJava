//Classe criada apenas para calcular o imposto e nçao haver repetição do código.
public class CalculadoraDeImposto {
	private double totalImposto;
	
	//Método específico
	public void registra(Tributavel t) {
		double valor = t.getValorImposto();
		this.totalImposto += valor;
	}

	//Método Getter e Setter
	public double getTotalImposto() {
		return totalImposto;
	}
}
