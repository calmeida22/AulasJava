public abstract class conta { //abstract indica que a classe é abstrata e não pode ter objeto instanciados, apenas as subs.
//atributos	
	private double saldo;
	private int agencia;
	private int numero;
	private String titular;

//método construtor	
	public conta(int agencia, int numero) {
		this.agencia = agencia;
		this.numero = numero;
		this.saldo = 100;
		System.out.println("Estou criando uma conta com AGENCIA e NUMERO");
	}
	
	
	public conta(int agencia, int numero, String titular) {
		this.agencia = agencia;
		this.numero = numero;
		this.titular = titular;
		System.out.println("Estou criando uma conta com AGENCIA, NUMERO e TITULAR");
	
	}

	public conta(double saldo, int agencia, int numero, String titular) {
		this.saldo = saldo;
		this.agencia = agencia;
		this.numero = numero;
		this.titular = titular;
		System.out.println("Estou criando uma conta com AGENCIA, NUMERO, TITULAR e SALDO");
	}


	//métodos específicos
	public abstract void deposita(double valor); /*{
		this.saldo += valor;// é o mesmo que "saldo = saldo + valor"
		System.out.println("Depósito realizado com sucesso!");
	}*/

	public boolean saca(double valor) {
		if (saldo >= valor) {
			this.saldo -= valor;
			System.out.println("Saque realizado com sucesso!");
			return true;
		}else {
			System.out.println("Saldo insuficiente para esse saque!");
			return false;
		}
		
	}
	
	public boolean transfere(double valor, conta destino) {
		if (saldo >= valor) {
			this.saldo -= valor;
			//destino.deposita(valor);para chamar o método deposita
			destino.saldo += valor;
			System.out.println("Transferência realizada com sucesso!");
			return true;
		
	}else {
		System.out.println("Saldo insuficiente para essa transferência!");
		return false;
	}
}
//métodos Getters e Setters
	public double getSaldo() {
		return this.saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public int getAgencia() {
		return this.agencia;
	}

	public void setAgencia(int agencia) {
		this.agencia = agencia;
	}

	public int getNumero() {
		return this.numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public String getTitular() {
		return this.titular;
	}

	public void setTitular(String titular) {
		this.titular = titular;
	}
		
}