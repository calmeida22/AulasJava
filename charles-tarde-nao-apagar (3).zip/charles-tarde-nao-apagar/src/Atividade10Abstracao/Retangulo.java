package Atividade10Abstracao;

public class Retangulo extends Quadrilatero {

//Método construtor
	Retangulo(double largura, double altura){
		super.setLargura(largura);
		super.setAltura(altura);
	}
	
//Métodos específicos	
	@Override
	public double calcularArea() {
		double area = super.getLargura()*super.getAltura();
		System.out.println("Calculando área do retângulo...");
		return area;
	}

	@Override
	public double calcularPerimetro() {
		double perimetro = 2*(super.getLargura()+super.getAltura());
		System.out.println("Calculando perímetro do retângulo...");
		return perimetro;
	}

}
