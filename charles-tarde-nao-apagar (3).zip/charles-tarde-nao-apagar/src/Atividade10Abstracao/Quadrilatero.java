package Atividade10Abstracao;

public abstract class Quadrilatero {
	private double largura;
	private double altura;
	private double raio;

//Métodos específicos
	public abstract double calcularArea();
	
	public	abstract double calcularPerimetro();

//Métodos Getters e Setters
	public double getLargura() {
		return this.largura;
	}
	
	public void setLargura(double largura) {
		this.largura = largura;
	}
	
	public double getAltura() {
		return this.altura;
	}
	
	public void setAltura(double altura) {
		this.altura = altura;
	}
	
	public double getRaio() {
		return this.raio;
	}
	
	public void setRaio(double raio) {
		this.raio = raio;
	}
}
