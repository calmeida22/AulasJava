package Atividade05Reescrita;

public class CriaPlanos {

	public static void main(String[] args) {
		Basico b1 = new Ouro();
		b1.setIdade(36);
		b1.setNome("Nome15");
		System.out.println("Nome: "+b1.getNome());
		System.out.println("Idade: "+b1.getIdade());
		System.out.println("Valor do plano: "+b1.calculaPreco());

	}

}
