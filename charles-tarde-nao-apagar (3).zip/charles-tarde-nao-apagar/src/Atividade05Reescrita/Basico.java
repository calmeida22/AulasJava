package Atividade05Reescrita;

public class Basico {
	private String nome;
	private int idade;
	
//Métodos especiais
	public double calculaPreco() {
		if (this.getIdade()<=30) {
			double valor = 1000*0.5;
			System.out.println("Plano Básico 0-30!");
			return valor;
		} else if (this.getIdade()>80) {
			double valor = 1000*0.8;
			System.out.println("Plano Básico acima 80!");
			return valor;
		} else {
			double valor = 1000*0.7;
			System.out.println("Plano Básico 31-80!");
			return valor;
		}
	}
	
	
//Métodos Getters e Setters	
	public String getNome() {
		return this.nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getIdade() {
		return this.idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	
	
}
