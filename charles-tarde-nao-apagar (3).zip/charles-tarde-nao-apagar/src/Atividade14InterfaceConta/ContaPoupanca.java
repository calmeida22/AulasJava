package Atividade14InterfaceConta;

public class ContaPoupanca implements Conta{

	private int agencia;
	private int numero;
	private int titular;
	private double saldo;

	//Métodos específicos
	@Override
	public double Deposita(double valor) {
		return this.saldo+=valor;
	}

	@Override
	public boolean Saca(double valor) {
		if(this.saldo>=valor) {
		this.saldo-=valor;	
		return true;
		} else {
			System.out.println("Saldo insuficiente para saque!");
			return false;
		}
	}

	@Override
	public boolean Transfere(double valor, Conta destino) {
		if (this.saldo>=valor) {
			this.saldo-=valor;
			destino.Deposita(valor);
			return true;
		} else {
			System.out.println("Saldo insuficiente para transferir!");
			return false;
		}
	}
//Métodos Getters e Setters

	public int getAgencia() {
		return this.agencia;
	}

	public void setAgencia(int agencia) {
		this.agencia = agencia;
	}

	public int getNumero() {
		return this.numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public int getTitular() {
		return this.titular;
	}

	public void setTitular(int titular) {
		this.titular = titular;
	}

	public double getSaldo() {
		return this.saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
}