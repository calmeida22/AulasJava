
public class ContaPoupanca extends conta {
	
//Contrutor	
	public ContaPoupanca(int agencia,int numero) {
		super(agencia,numero);
	}
	
	//public void deposita(double valor) {
		//super.getSaldo()+=valor;
//	}
	
	@Override
		public boolean saca(double valor) {
			if (valor<1000) {
				System.out.println("Saque realizado. Sem taxa.");
				return super.saca(valor);
			} else {
				double valorAsacar = valor + 0.2;
				System.out.println("Saque ralizado. Taxa de R$0,20.");
				return super.saca(valorAsacar);
			}						
		}

	@Override
	public void deposita(double valor) {
		super.setSaldo(valor+super.getSaldo());
		
	}
}
