package Atividade10Abstracao;

public class Teste {

	public static void main(String[] args) {
		Retangulo r1 = new Retangulo(2,4);
		System.out.println(r1.calcularArea()+"m²");
		System.out.println(r1.calcularPerimetro()+"m");
		
		System.out.println();
		
		Circulo c1 = new Circulo(3);
		System.out.println(c1.calcularArea()+"m²");
		System.out.println(c1.calcularPerimetro()+"m");
		
		System.out.println();
		
		Quadrado q1 = new Quadrado(4);
		System.out.println(q1.calcularArea()+"m²");
		System.out.println(q1.calcularPerimetro()+"m");
		
		System.out.println();
		
		System.out.println("Retângulo \nAltura: "+r1.getAltura()+"\nLargura: "+r1.getLargura()+"\nRaio: "+r1.getRaio());
		System.out.println();
		System.out.println("Círculo \nAltura: "+c1.getAltura()+"\nLargura: "+c1.getLargura()+"\nRaio: "+c1.getRaio());
		System.out.println();
		System.out.println("Quadrado \nAltura: "+q1.getAltura()+"\nLargura: "+q1.getLargura()+"\nRaio: "+q1.getRaio());

	}

}
