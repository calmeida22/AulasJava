package Atividade10Abstracao;

public class Quadrado extends Quadrilatero {

//Método construtor
	Quadrado(double largura){
		super.setLargura(largura);
	}
	
//Método específico
	@Override
	public double calcularArea() {
		double area = super.getLargura()*super.getLargura();
		System.out.println("Calculando área do quadrado...");
		return area;
	}

	@Override
	public double calcularPerimetro() {
		double perimetro = 4*super.getLargura();
		System.out.println("Calculando perímetro do quadrado...");
		return perimetro;
	}

}
