
public class TesteTributaveis {

	public static void main(String[] args) {
		ContaCorrente cc = new ContaCorrente(222,333);
		System.out.println("Agencia: "+cc.getAgencia()+"\nNumero: "+cc.getNumero()+"\nTitular: "+cc.getTitular()+"\nSaldo: "+cc.getSaldo());
		cc.deposita(100);
		System.out.println("Saldo: "+cc.getSaldo());
	
	SeguroDeVida seguro = new SeguroDeVida();
	
	CalculadoraDeImposto calc = new CalculadoraDeImposto();
	
	calc.registra(cc);
	calc.registra(seguro);
	
	System.out.println(calc.getTotalImposto());
	}


}
