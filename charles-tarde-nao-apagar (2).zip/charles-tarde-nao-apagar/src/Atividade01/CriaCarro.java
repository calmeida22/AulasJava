package Atividade01;

public class CriaCarro {

	public static void main(String[] args) {
		Carro carro = new Carro("GOL");
		System.out.println("Ano: "+carro.getAno()+"\nModelo: "+carro.getModelo()+"\nPreço: "+carro.getPreco());
		
		System.out.println();
		
		Carro carro2 = new Carro("KA");
		System.out.println("Ano: "+carro2.getAno()+"\nModelo: "+carro2.getModelo()+"\nPreço: "+carro2.getPreco());
		
		System.out.println();
		
		Carro carro3 = new Carro(2003,"PALIO",12000.00);
		System.out.println("Ano: "+carro3.getAno()+"\nModelo: "+carro3.getModelo()+"\nPreço: "+carro3.getPreco());

	}

}
