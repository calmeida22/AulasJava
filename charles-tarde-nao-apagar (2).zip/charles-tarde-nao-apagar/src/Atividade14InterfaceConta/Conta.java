package Atividade14InterfaceConta;

public interface Conta {
	
	public abstract double Deposita(double valor);
	
	public abstract boolean Saca(double valor);
	
	public abstract boolean Transfere(double valor, Conta destino);

}
