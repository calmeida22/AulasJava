package Atividade14InterfaceConta;

public class Teste {

	public static void main(String[] args) {
		ContaCorrente cc = new ContaCorrente();
		ContaPoupanca cp = new ContaPoupanca();
		
		System.out.println("Saldo Corrente: "+cc.getSaldo()+"\nSaldo Poupança: "+cp.getSaldo());
		
		cc.Deposita(100);
		cp.Deposita(100);
		
		System.out.println("Saldo Corrente: "+cc.getSaldo()+"\nSaldo Poupança: "+cp.getSaldo());
		
		cc.Saca(50);
		cp.Saca(50);
		
		System.out.println("Saldo Corrente: "+cc.getSaldo()+"\nSaldo Poupança: "+cp.getSaldo());
		
		cc.Transfere(25, cp);
		cp.Transfere(10, cc);
		
		System.out.println("Saldo Corrente: "+cc.getSaldo()+"\nSaldo Poupança: "+cp.getSaldo());
		
		ContaCorrente cc2 = new ContaCorrente();
		
		cc.Transfere(25, cc2);
		System.out.println("Saldo Corrente: "+cc.getSaldo()+"\nSaldo Corrente2: "+cc2.getSaldo());
		
		ContaPoupanca cp2 = new ContaPoupanca();
		
		cp.Transfere(500, cp2);
		System.out.println("Saldo Poupança: "+cp.getSaldo()+"\nSaldo Poupança2: "+cp2.getSaldo());

	}

}
