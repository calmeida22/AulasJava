package Atividade05Reescrita;

public class Prata extends Basico{
	
	@Override
	public double calculaPreco() {
		if (this.getIdade()<=30) {
			double valor = 1400*0.5;
			System.out.println("Plano Prata 0-30!");
			return valor;
		} else if (this.getIdade()>80) {
			double valor = 1400*0.7;
			System.out.println("Plano Prata acima 80!");
			return valor;
		} else {
			double valor = 1400*0.8;
			System.out.println("Plano Prata 31-80!");
			return valor;
		}
	}
}
