package Atividade14InterfaceComposição;

public class ContaUtil {
	
	private int agencia;
	private int numero;
	private String titular;
	private double saldo;
		
	public double Deposita(double valor) {
		return this.saldo+=valor;
	}

	public boolean Saca(double valor) {
		if(this.saldo>=valor) {
		this.saldo-=valor;	
		return true;
		} else {
			System.out.println("Saldo insuficiente para saque!");
			return false;
		}
	}

	public boolean Transfere(double valor, Conta destino) {
		if (this.saldo>=valor) {
			this.saldo-=valor;
			destino.Deposita(valor);
			return true;
		} else {
			System.out.println("Saldo insuficiente para transferir!");
			return false;
		}
	}
	
	//Métodos Getters e Setters
		public int getAgencia() {
			return this.agencia;
		}

		public void setAgencia(int agencia) {
			this.agencia = agencia;
		}

		public int getNumero() {
			return this.numero;
		}

		public void setNumero(int numero) {
			this.numero = numero;
		}

		public String getTitular() {
			return this.titular;
		}

		public void setTitular(String titular) {
			this.titular = titular;
		}

		public double getSaldo() {
			return this.saldo;
		}

		public void setSaldo(double saldo) {
			this.saldo = saldo;
	
}
		
}
