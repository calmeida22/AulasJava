package Atividade14InterfaceComposição;

public class ContaPoupanca implements Conta{

	private ContaUtil util;
	
	public ContaPoupanca(){
		this.util = new ContaUtil();
	}

	//Métodos específicos
	@Override
	public double Deposita(double valor) {
		return this.util.Deposita(valor);
	}

	@Override
	public boolean Saca(double valor) {
		return this.util.Saca(valor);
	}

	@Override
	public boolean Transfere(double valor, Conta destino) {
		return this.util.Transfere(valor, destino);
	}
//Métodos Getters e Setters

	public int getAgencia() {
		return this.util.getAgencia();
	}

	public void setAgencia(int agencia) {
		this.util.setAgencia(agencia);
	}

	public int getNumero() {
		return this.util.getNumero();
	}

	public void setNumero(int numero) {
		this.util.setNumero(numero);
	}

	public String getTitular() {
		return this.util.getTitular();
	}

	public void setTitular(String titular) {
		this.util.setTitular(titular);
	}

	public double getSaldo() {
		return this.util.getSaldo();
	}

	public void setSaldo(double saldo) {
		this.util.setSaldo(saldo);
	}
	
}