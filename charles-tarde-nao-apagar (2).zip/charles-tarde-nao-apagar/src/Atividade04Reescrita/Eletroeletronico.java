package Atividade04Reescrita;

public class Eletroeletronico extends Produto {
	
	@Override
	public double calculaPreco() {
		double desconto = super.getpreco()*0.05;
		System.out.println("Desconto: "+desconto);
		return super.getpreco()-desconto;
}

}