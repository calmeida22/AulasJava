package Atividade04Reescrita;

public class CriaProduto {

	public static void main(String[] args) {
		
		Produto p1 = new Produto();
		p1.setNome("Produto1");
		p1.setPreco(100);
		
		System.out.println("À pagar: "+p1.calculaPreco());
		System.out.println();
		
		BelezaSaude bs1 = new BelezaSaude();
		bs1.setNome("BelezaSaude1");
		bs1.setPreco(100);
		
		System.out.println("À pagar: "+bs1.calculaPreco());
		System.out.println();
		
		Moveis m1 = new Moveis();
		m1.setNome("Moveis1");
		m1.setPreco(100);
		
		System.out.println("À pagar: "+m1.calculaPreco());
		System.out.println();
		
		Eletrodomesticos e1 = new Eletrodomesticos();
		e1.setNome("Eletrodomestico1");
		e1.setPreco(100);
		
		System.out.println("À pagar: "+e1.calculaPreco());
		System.out.println();
		
		Eletroeletronico el1 = new Eletroeletronico();
		el1.setNome("Eletroeletronico1");
		el1.setPreco(100);
		
		System.out.println("À pagar: "+el1.calculaPreco());
		System.out.println();
		
		BelezaSaude bs2 = new BelezaSaude();
		System.out.println(bs2.calculaPreco(200));
		System.out.println("Preço: "+bs2.getpreco());
		
	}

}
