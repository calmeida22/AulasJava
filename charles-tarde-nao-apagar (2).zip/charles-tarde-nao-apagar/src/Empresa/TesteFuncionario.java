package Empresa;

public class TesteFuncionario {

	public static void main(String[] args) {
		Atendente nico = new Atendente();
		
		nico.setNome("Nico Steppat");
		nico.setCpf("223.355.646-09");
		nico.setSalario(2590.80);
				
		System.out.println("Nome: "+nico.getNome()+"\nCPF: "+nico.getCpf()+"\nSalário: "+nico.getSalario()+"\nTipo: ");
		
		
		System.out.println("Bonificação: "+nico.getBonificacao());
	}

}
