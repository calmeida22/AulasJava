package Empresa;

public abstract interface Autenticavel{
	//private int senha; //copiado do diretor (aula interface), que são filhas
	
	public abstract void setSenha(int senha);// {copiado do diretor (aula interface), que são filhas
	//	this.senha = senha;
	//}
	
	public abstract boolean autentica(int senha);/* {
		if (this.senha == senha) {
			return true;
		} else {
			return false;
		}
	}*/
}
