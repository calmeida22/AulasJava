package Empresa;

public class TesteDiretor {

	public static void main(String[] args) {
		Diretor d1 = new Diretor();
		d1.setCpf("555.666.777-88");
		d1.setNome("Diretor01");
		d1.setSalario(25000);
		
		System.out.println("Bonificação Diretor: "+d1.getBonificacao());
	}

}
