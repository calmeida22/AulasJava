package Empresa;

public class TesteAtendente {

	public static void main(String[] args) {
		Atendente a1 = new Atendente();
		a1.setCpf("222.555.777-99");
		a1.setNome("Atndente01");
		a1.setSalario(2000);

		System.out.println("Bonificação atendente: "+a1.getBonificacao());
	}

}
