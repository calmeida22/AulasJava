package Empresa;

public class TesteGerente {

	public static void main(String[] args) {
		
		Gerente gerente1 = new Gerente();
		gerente1.setNome("João Paulo");
		gerente1.setCpf("231.256.554-88");
		gerente1.setSalario(4500.00);
		gerente1.setSenha(1234);
//		gerente1.setLogin("ABC");
				
		System.out.println("Nome: "+gerente1.getNome()+"\nCPF: "+gerente1.getCpf()+"\nSalário: "+gerente1.getSalario()+"\nTipo: ");
		
		System.out.println("Bonificação Gerente1: "+gerente1.getBonificacao());
		
		boolean autenticou = gerente1.autentica(1234);
		System.out.println("Senha OK?: "+autenticou);
	
		boolean autenticou2 = gerente1.autentica(1324);
		System.out.println("Senha OK?: "+autenticou2);
		
		boolean autenticou3 = gerente1.autentica(1234);
		System.out.println("Senha OK?: "+autenticou3);
		
		boolean autenticou4 = gerente1.autentica(1324);
		System.out.println("Senha OK?: "+autenticou4);
		
	}

}
