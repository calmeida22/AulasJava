package Atividade03Heranca;

public class Professor extends Funcionario {
	private String disciplina;
	
//Métodos Getters e Setters
	public String getDisciplina() {
		return this.disciplina;
	}
	
	public void setDisciplina(String disciplina) {
		this.disciplina = disciplina;
	}
}
