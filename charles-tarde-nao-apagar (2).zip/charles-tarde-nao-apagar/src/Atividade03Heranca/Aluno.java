package Atividade03Heranca;

public class Aluno extends Pessoa{
	private String semestre;
	private String curso;

//Métodos Getters e Setters
	public String getSemestre() {
		return this.semestre;
	}
	
	public void setSemestre(String semestre) {
		this.semestre = semestre;
	}
	
	public String getCurso() {
		return this.curso;
	}
	
	public void setCurso(String curso) {
		this.curso = curso;
	}
}
