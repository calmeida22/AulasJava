package Atividade03Heranca;

public class Funcionario extends Pessoa {
	private double salario;

//Métodos Getters e Setters
	public double getSalario() {
		return this.salario;
	}
	
	public void setSalario(double valor) {
		this.salario = valor;
	}

}
