package Atividade03Heranca;

public class CriaTestes {

	public static void main(String[] args) {
		Pessoa p1 = new Pessoa();
		System.out.println("Instanciando PESSOA");
		p1.setNome("Pessoa1");
		p1.setIdade(25);
		p1.setEndereco("Rua A");
		System.out.println("Nome: "+p1.getNome()+"\nIdade: "+p1.getIdade()+"\nEndereço: "+p1.getEndereco());

		System.out.println();
		
		Funcionario f1 = new Funcionario();
		System.out.println("Instanciando FUNCIONARIO");
		f1.setSalario(1500.22);
		f1.setNome("Funcionario1");
		f1.setIdade(30);
		f1.setEndereco("Rua B");
		System.out.println("Salário: "+f1.getSalario()+"\nNome: "+f1.getNome()+"\nIdade: "+f1.getIdade()+"\nEndereço: "+f1.getEndereco());
		
		System.out.println();
		
		Aluno a1 = new Aluno();
		System.out.println("Instanciando ALUNO");
		a1.setSemestre("Terceiro");
		a1.setCurso("Sistemas");
		a1.setNome("Aluno01");
		a1.setIdade(18);
		a1.setEndereco("Rua C");
		System.out.println("Semestre: "+a1.getSemestre()+"\nCurso: "+a1.getCurso()+"\nNome: "+a1.getNome()+"\nIdade: "+a1.getIdade()+"\nEndereço: "+a1.getEndereco());
		
		System.out.println();
		
		Professor pf1 = new Professor();
		System.out.println("Instanciando PROFESSOR");
		pf1.setDisciplina("Tecnologia");
		pf1.setNome("Professor01");
		pf1.setIdade(40);
		pf1.setEndereco("Rua D");
		pf1.setSalario(2000.00);
		System.out.println("Disciplina: "+pf1.getDisciplina()+"\nNome: "+pf1.getNome()+"\nIdade: "+pf1.getIdade()+"\nEndereço: "+pf1.getEndereco()+"\nSalário: "+pf1.getSalario());
		
		System.out.println();
		
		FuncAdm fa1 = new FuncAdm ();
		System.out.println("Instanciando FUNC_ADM");
		fa1.setSetor("Financeiro");
		fa1.setFuncao("Contador");
		fa1.setNome("Func01");
		fa1.setIdade(41);
		fa1.setEndereco("Rua E");
		fa1.setSalario(1500.54);
		System.out.println("Setor: "+fa1.getSetor()+"\nFunção: "+fa1.getFuncao()+"\nNome: "+fa1.getNome()+"\nIdade: "+fa1.getIdade()+"\nEndereço: "+fa1.getEndereco()+"\nSalário: "+fa1.getSalario());
		
	}

}
