package Atividade03Heranca;

public class FuncAdm extends Funcionario {
	private String setor;
	private String funcao;
	
//Métodos Getters e Setter
	public String getSetor() {
		return this.setor;
	}
	
	public void setSetor(String setor) {
		this.setor = setor;
	}
	
	public String getFuncao() {
		return this.funcao;
	}
	
	public void setFuncao(String funcao) {
		this.funcao = funcao;
	}
}
