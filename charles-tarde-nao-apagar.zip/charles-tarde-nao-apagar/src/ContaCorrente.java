
public class ContaCorrente extends conta {

//Contrutor
	public ContaCorrente(int agencia, int numero) {
		super(agencia,numero); //esse parametros estão na classe super
	}
	
	@Override
		public boolean saca(double valor) {
			double valorASacar = valor + 0.2;
			System.out.println("Saque realizado! Taxa de R$0,20");
			return super.saca(valorASacar);
		}

	@Override
		public void deposita(double valor) {
			super.setSaldo(valor+super.getSaldo());
		
	}
}
