package Atividade02;

public class CriaProduto {

	public static void main(String[] args) {
		
		Produto P1 = new Produto(0);
		System.out.println("Codigo: "+P1.getCodigo()+"\nNome: "+P1.getNome()+"\nPreço: "+P1.getPreco()+"\nQuantidade: "+P1.getQuantidade());
		
		System.out.println();
		
		Produto p2 = new Produto(123);
		//p2.setCodigo(123);
		p2.setNome("Doméstico");
		p2.setPreco(23.99);
		p2.setQuantidade(51);
		System.out.println("Codigo: "+p2.getCodigo()+"\nNome: "+p2.getNome()+"\nPreço: "+p2.getPreco()+"\nQuantidade: "+p2.getQuantidade());
		
		System.out.println();
		
		Produto p3 = new Produto(125,"Alimento");
		System.out.println("Codigo: "+p3.getCodigo()+"\nNome: "+p3.getNome()+"\nPreço: "+p3.getPreco()+"\nQuantidade: "+p3.getQuantidade());
		
		System.out.println();
		
		Produto p4 = new Produto(126,"Limpeza",12.54,75);
		System.out.println("Codigo: "+p4.getCodigo()+"\nNome: "+p4.getNome()+"\nPreço: "+p4.getPreco()+"\nQuantidade: "+p4.getQuantidade());
		
	}

}
