package Empresa;

public class Cliente implements Autenticavel {//Assinatura de contrato: implements permite acesso ao métodos abstratos que são implemntados

	private AutenticacaoUtil autenticou;
	
	public Cliente() {
		this.autenticou = new AutenticacaoUtil();
	}
	
	@Override
	public void setSenha(int senha) {
		this.autenticou.setSenha(senha);
	}
		
	@Override
	public boolean autentica(int senha) {
		if (this.autenticou.autentica(senha)){
			return this.autenticou.autentica(senha);
		} else {
			return false;
		}
	}
	
}
