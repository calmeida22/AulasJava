package Empresa;

public class Secretaria extends Funcionario {

	@Override
	public double getBonificacao() {
		return super.getSalario()*0.5;
		
	}

}
