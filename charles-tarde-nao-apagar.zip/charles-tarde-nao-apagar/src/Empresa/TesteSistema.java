package Empresa;

public class TesteSistema {

	public static void main(String[] args) {
		Gerente g = new Gerente();
		g.setNome("Charles");
		System.out.println(g.getNome());
		g.setSenha(2221);
		
		Diretor d = new Diretor();
		d.setSenha(2222);
		
		Cliente c = new Cliente();
		c.setSenha(2221);
		Secretaria s = new Secretaria(); 
		//s.setSenha(2232);
		
		SistemaInterno si = new SistemaInterno();
		si.autentica(g);
		si.autentica(d);
		//si.autentica(s); Não herdade funcionario autenticavel
		si.autentica(c);
		
	}

}
