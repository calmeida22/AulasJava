package Empresa;

public class Gerente extends Funcionario implements Autenticavel {

	private AutenticacaoUtil autenticou;
	
	public Gerente (){
		this.autenticou = new AutenticacaoUtil();
	}
	
	//private String login;

//Método sobrecarga (independe de herança)
/*	public boolean autentica(int senha) {
		if (this.senha == senha) {
			return true;
		} else {
			return false;
		}
	}
	
	public boolean autentica(String login, int senha) {
		if (this.login == login && this.senha == senha) {
			return true;			
		} else {
			return false;
		}
	}*/
	
	@Override
	public double getBonificacao() {
		return super.getSalario(); //super para indicar que salário é atributo da classe mãe (boa prática)
		//return this.salario; //salário visível pois é protected em funcionario
	}

	@Override
	public void setSenha(int senha) {
		this.autenticou.setSenha(senha);
	}
		
	@Override
	public boolean autentica(int senha) {
		if (this.autenticou.autentica(senha)){
			return this.autenticou.autentica(senha);
		} else {
			return false;
		}
	}
	
	/*public void setSenha(int senha) {
		this.senha = senha;
	}*/
	
	//public void setLogin(String login) {
		
	//}
	
}
