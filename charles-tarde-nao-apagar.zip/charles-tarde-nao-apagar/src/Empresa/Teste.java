package Empresa;

public class Teste {

	public static void main(String[] args) {
		Gerente g1 = new Gerente();
		Diretor d1 = new Diretor();
		Atendente a1 = new Atendente();
		
	g1.setSalario(1000);
	System.out.println("Gerente Bonificação R$"+g1.getBonificacao());
	
	d1.setSalario(1000);
	System.out.println("Diretor Bonificação R$"+d1.getBonificacao());
	
	a1.setSalario(1000);
	System.out.println("Atendente Bonificação R$"+a1.getBonificacao());
	
		Secretaria s1 = new Secretaria();
		
	s1.setSalario(1000);
	System.out.println("Secretaria Bonificação R$"+s1.getBonificacao());

	}

}
