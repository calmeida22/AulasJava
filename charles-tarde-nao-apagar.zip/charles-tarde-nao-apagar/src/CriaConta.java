public class CriaConta {

	public static void main(String[] args) {
/*		conta primeiraConta = new conta(872,666);
		//primeiraConta.setAgencia(872);
		//primeiraConta.setNumero(666);
		primeiraConta.setTitular("Charles");
		primeiraConta.setSaldo(2500);
		
		conta segundaConta = new conta(872,777);
		//segundaConta.setAgencia(872);
		//segundaConta.setNumero(777);
		segundaConta.setTitular("Almeida");
		segundaConta.setSaldo(2500);
		
		System.out.println("Saldo conta "+primeiraConta.getNumero()+" é: "+primeiraConta.getSaldo());
		System.out.println("Titular: "+primeiraConta.getTitular()+" - Agência: "+primeiraConta.getAgencia());
		System.out.println();
		System.out.println("Saldo conta "+segundaConta.getNumero()+" é: "+segundaConta.getSaldo());
		System.out.println("Titular: "+primeiraConta.getTitular()+" - Agência: "+primeiraConta.getAgencia());
		
		primeiraConta.deposita(100);
		
		System.out.println();
		System.out.println("Depósito 100 --> Saldo atualizado: "+primeiraConta.getTitular()+" é "+primeiraConta.getSaldo());
		
		segundaConta.deposita(542.26);
		
		System.out.println();
		System.out.println("Depósito 542,26 --> Saldo atualizado: "+segundaConta.getTitular()+" é "+segundaConta.getSaldo());
		
		primeiraConta.saca(2500);
		
		System.out.println();
		System.out.println("Saque 2500 --> Saldo atualizado: "+primeiraConta.getTitular()+" é "+primeiraConta.getSaldo());
		
		segundaConta.saca(3100);
		
		System.out.println();
		System.out.println("Saque 3100 --> Saldo atualizado: "+segundaConta.getTitular()+" é "+segundaConta.getSaldo());
		
		System.out.println();
		segundaConta.transfere(1520.56, primeiraConta);
		System.out.println("Saldo conta "+primeiraConta.getNumero()+" é: "+primeiraConta.getSaldo());
		System.out.println("Saldo conta "+segundaConta.getNumero()+" é: "+segundaConta.getSaldo());
		
		System.out.println();
		
		conta terceiraConta = new conta(888,9999);
					
		System.out.println("Agência: "+terceiraConta.getAgencia()+"\nNúmero: "+terceiraConta.getNumero()+"\nSaldo: "+terceiraConta.getSaldo()+"\nTitular: "+terceiraConta.getTitular());
		
		System.out.println();
		
		conta quartaConta = new conta(555,2222,"NovoUsuário");
		
		System.out.println("Agência: "+quartaConta.getAgencia()+"\nNúmero: "+quartaConta.getNumero()+"\nSaldo: "+quartaConta.getSaldo()+"\nTitular: "+quartaConta.getTitular());
		
		System.out.println();
		
		conta quintaConta = new conta(156.59,444,1111,"OutroUsuário");
		System.out.println("Agência: "+quintaConta.getAgencia()+"\nNúmero: "+quintaConta.getNumero()+"\nSaldo: "+quintaConta.getSaldo()+"\nTitular: "+quintaConta.getTitular());
		*/
		ContaPoupanca cp1 = new ContaPoupanca(456,7890);
		cp1.setSaldo(1000);	
		
		ContaCorrente cc1 = new ContaCorrente(123,1234);
		cc1.setTitular("Corrente01");
		cc1.setSaldo(1000);
		System.out.println("Agência: "+cc1.getAgencia()+"\nNúmero: "+cc1.getNumero()+"\nSaldo: "+cc1.getSaldo()+"\nTitular: "+cc1.getTitular());
		cc1.deposita(500);
		System.out.println("Saldo atual: "+cc1.getSaldo());
		cc1.transfere(100, cp1);
		System.out.println("Saldo atual: "+cc1.getSaldo());

		System.out.println();
		
		
		cp1.setTitular("Poupanca01");
		System.out.println("Agência: "+cp1.getAgencia()+"\nNúmero: "+cp1.getNumero()+"\nSaldo: "+cp1.getSaldo()+"\nTitular: "+cp1.getTitular());
		cp1.deposita(200);
		System.out.println("Saldo atual: "+cp1.getSaldo());
		cp1.transfere(100, cc1);
		System.out.println("Saldo atual: "+cp1.getSaldo());
		
		System.out.println();
		
		cc1.saca(10);
		System.out.println("Saldo corrente: "+cc1.getSaldo());
		
		cp1.saca(10);
		System.out.println("Saldo poupança: "+cp1.getSaldo());
	
		//conta cc2 = new conta(); //não é possível instanciar classe abstrata
	}
	
	

}
