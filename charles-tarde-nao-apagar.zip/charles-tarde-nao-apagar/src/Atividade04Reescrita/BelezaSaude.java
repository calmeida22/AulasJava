package Atividade04Reescrita;

public class BelezaSaude extends Produto {
	
	//public double calculaPreco() {
		//double desconto = super.getpreco()*0.1;
		//System.out.println("Desconto: "+desconto);
		//return super.getpreco()-desconto;
		
//}
	public double calculaPreco(double valor) { //para não precisar setar o valor
		double desconto = valor*0.1;
		System.out.println("Desconto: "+desconto);
		super.setPreco(valor);
		return super.getpreco()-desconto;
	}
}