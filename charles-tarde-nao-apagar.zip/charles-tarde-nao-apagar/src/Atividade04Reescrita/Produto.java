package Atividade04Reescrita;

public class Produto {
	private String nome;
	private double preco;

//Métodos específicos
	public double calculaPreco() {
		double desconto = this.preco*0;
		System.out.println("Desconto: "+desconto);
		return this.preco-desconto;
	}
//Métodos getters e setters
	public String getNome() {
		return this.nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public double getpreco() {
		return this.preco;
	}
	
	public void setPreco(double preco) {
		this.preco = preco;
	}
}
