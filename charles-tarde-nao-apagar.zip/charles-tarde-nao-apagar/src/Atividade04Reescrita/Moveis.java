package Atividade04Reescrita;

public class Moveis extends Produto {
	
	@Override
	public double calculaPreco() {
		double desconto = super.getpreco()*0.2;
		System.out.println("Desconto: "+desconto);
		return super.getpreco()-desconto;
}

}