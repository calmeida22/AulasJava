package Atividade05Reescrita;

public class Diamante extends Basico{
	
	@Override
	public double calculaPreco() {
		if (this.getIdade()<=30) {
			double valor = 2000*0.5;
			System.out.println("Plano Diamante 0-30!");
			return valor;
		} else if (this.getIdade()>80) {
			double valor = 2000*0.7;
			System.out.println("Plano Diamante acima 80!");
			return valor;
		} else {
			double valor = 2000*0.8;
			System.out.println("Plano Diamante 31-80!");
			return valor;
		}
	}

}
