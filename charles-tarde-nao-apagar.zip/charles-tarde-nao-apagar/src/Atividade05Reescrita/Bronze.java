package Atividade05Reescrita;

public class Bronze extends Basico {
	
	@Override
	public double calculaPreco() {
		if (this.getIdade()<=30) {
			double valor = 1200*0.5;
			System.out.println("Plano Bronze 0-30!");
			return valor;
		} else if (this.getIdade()>80) {
			double valor = 1200*0.8;
			System.out.println("Plano Bronze acima 80!");
			return valor;
		} else {
			double valor = 1200*0.7;
			System.out.println("Plano Bronze 31-80!");
			return valor;
		}
	}
}
