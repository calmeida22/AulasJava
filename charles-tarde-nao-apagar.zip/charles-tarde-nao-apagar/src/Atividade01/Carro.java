package Atividade01;

public class Carro {
	private int ano;
	private String modelo;
	private double preco;
	
//Método construtor	
	public Carro(String modelo) {
		this.modelo = modelo;
		System.out.println("Estou criando objeto com MODELO");
	}
		
	public Carro(int ano, String modelo, double preco) {
		this.ano = ano;
		this.modelo = modelo;
		this.preco = preco;
		System.out.println("Estou criando objeto com ANO, MODELO, PRECO");
}

//Métodos Getters e Setters	
	public int getAno() {
		return this.ano;
	}
	
	public void setAno(int ano) {
		this.ano = ano;
	}
	public String getModelo() {
		return this.modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}
	public double getPreco() {
		return this.preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}
		
}
