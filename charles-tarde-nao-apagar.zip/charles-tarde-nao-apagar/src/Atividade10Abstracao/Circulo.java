package Atividade10Abstracao;

public class Circulo extends Quadrilatero{

//Método construtor
	Circulo(double raio){
		super.setRaio(raio);
	}
	
//Métodos específicos
	@Override
	public double calcularArea() {
		double area = (Math.pow(super.getRaio(),2))*3.14; //Math.pow biblioteca para exponencial (base,exponencial);
		System.out.println("Calculando área do círculo...");
		return area;
	}

	@Override
	public double calcularPerimetro() {
		double perimetro = super.getRaio()*(2*3.14);
		System.out.println("Calculando perímetro do círculo...");
		return perimetro;
	}

}
